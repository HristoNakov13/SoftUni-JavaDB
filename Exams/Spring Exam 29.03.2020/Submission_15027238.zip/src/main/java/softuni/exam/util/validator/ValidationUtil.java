package softuni.exam.util.validator;

public interface ValidationUtil {

    <E> boolean isValid(E entity);
}
