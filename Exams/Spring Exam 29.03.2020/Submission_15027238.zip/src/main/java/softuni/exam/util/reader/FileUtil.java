package softuni.exam.util.reader;

import java.io.IOException;

public interface FileUtil {

    String getFileContent(String path) throws IOException;
}
