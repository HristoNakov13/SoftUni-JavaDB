package softuni.exam.domain.entities.enums;

public enum  Rating {
    GOOD,
    BAD,
    UNKNOWN;
}
