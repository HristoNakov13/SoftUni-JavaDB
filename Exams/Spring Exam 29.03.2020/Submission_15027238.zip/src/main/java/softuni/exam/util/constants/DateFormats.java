package softuni.exam.util.constants;

public class DateFormats {

    public static String CARS_JSON_DATE_FORMAT = "dd/MM/yyyy";

    public static String PICTURES_JSON_DATETIME_FORMAT = "yyyy-MM-dd HH:mm:ss";

    public static String OFFERS_XML_DATETIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
}
